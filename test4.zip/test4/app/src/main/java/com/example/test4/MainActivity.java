package com.example.test4;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Spinner;
import android.widget.ArrayAdapter;

public class MainActivity extends AppCompatActivity {

    // ประกาศแถวลำดับ Array สำหรับเก็บชื่อวันทั้ง 7 วัน
    String[] daysOfWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ประกาศ Spinner
        Spinner spinner = findViewById(R.id.spinner);

        // สร้าง ArrayAdapter สำหรับ Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, daysOfWeek);

        // ตั้งค่ารูปแบบการแสดงของ Spinner
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // กำหนด Adapter ให้กับ Spinner
        spinner.setAdapter(adapter);

        // ตั้งค่ารายการที่เลือกเริ่มต้นของ Spinner (ถ้าต้องการ)
        spinner.setSelection(0);
    }
}
