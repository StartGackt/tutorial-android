package com.example.test2;

public class WaterCalculator {
    public static int calculateWaterCost(int units) {
        int price;

        if (units >= 1 && units <= 5) {
            price = units * 7;
        } else if (units >= 6 && units <= 10) {
            price = (5 * 7) + ((units - 5) * 6);
        } else {
            price = (5 * 7) + (5 * 6) + ((units - 10) * 11);
        }

        return price;
    }
}

